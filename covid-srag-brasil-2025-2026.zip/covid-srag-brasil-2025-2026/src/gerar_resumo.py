"""
Gera resumo.json (poucos KB) a partir dos Parquet/CSV do SIVEP-Gripe,
para carregar na página web para celular.

  pip install pandas pyarrow
  python gerar_resumo.py INFLUD25-16-11-2026.parquet INFLUD26-16-11-2026.parquet
  (opcional: --todas  para NÃO limitar 2025 às semanas já existentes em 2026)
"""
import json, re, sys
import pandas as pd

COLS = ["SEM_NOT", "SG_UF", "CLASSI_FIN", "EVOLUCAO", "UTI", "HOSPITAL",
        "NU_IDADE_N", "TP_IDADE", "SUPORT_VEN"]


def ler(path):
    if path.lower().endswith(".parquet"):
        import pyarrow.parquet as pq
        nomes = [c for c in pq.ParquetFile(path).schema_arrow.names if c.upper() in COLS]
        df = pd.read_parquet(path, columns=nomes)
    else:
        df = pd.read_csv(path, sep=";", encoding="latin-1", low_memory=False,
                         usecols=lambda c: c.upper() in COLS)
    df.columns = [c.upper() for c in df.columns]
    for c in ["SEM_NOT", "CLASSI_FIN", "EVOLUCAO", "UTI", "HOSPITAL", "NU_IDADE_N", "TP_IDADE"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    m = re.search(r"INFLUD(\d{2})", path.upper())
    df["ano"] = int("20" + m.group(1))
    return df


args = [a for a in sys.argv[1:] if not a.startswith("--")]
df = pd.concat([ler(a) for a in args], ignore_index=True)
df = df[df["CLASSI_FIN"] == 5]                      # SRAG por covid-19
if "--todas" not in sys.argv:
    df = df[df["SEM_NOT"] <= df.loc[df["ano"] == df["ano"].max(), "SEM_NOT"].max()]

div = df["TP_IDADE"].map({1: 365, 2: 12, 3: 1})
df["faixa"] = pd.cut(df["NU_IDADE_N"] / div, [-1, 4, 11, 19, 39, 59, 79, 200],
                     labels=["0-4", "5-11", "12-19", "20-39", "40-59", "60-79", "80+"])
df["int"] = df["HOSPITAL"].eq(1)
df["uti"] = df["UTI"].eq(1)

out = {"anos": {}, "filtro": "SRAG por covid-19 (CLASSI_FIN=5)",
       "semanas_alinhadas": "--todas" not in sys.argv}
for ano, g in df.groupby("ano"):
    out["anos"][str(ano)] = {
        "casos": int(len(g)),
        "internados": int(g["int"].sum()),
        "uti": int((g["int"] & g["uti"]).sum()),
        "int_enf": int((g["int"] & ~g["uti"]).sum()),
        "obitos": int(g["EVOLUCAO"].eq(2).sum()),
        "vent_invasiva": int(g["SUPORT_VEN"].astype(str).str.startswith("1").sum()),
        "semanal": {str(int(k)): int(v) for k, v in g.groupby("SEM_NOT").size().items()},
        "faixa": {str(k): int(v) for k, v in g.groupby("faixa", observed=True).size().items()},
        "uf": {str(k): int(v) for k, v in g.groupby("SG_UF").size().items()},
    }
json.dump(out, open("resumo.json", "w", encoding="utf-8"), ensure_ascii=False)
print("resumo.json gerado:", {a: v["casos"] for a, v in out["anos"].items()})
