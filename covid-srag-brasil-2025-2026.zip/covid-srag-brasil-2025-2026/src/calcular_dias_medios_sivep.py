"""
Médias reais de dias de internação (enfermaria e UTI) no SIVEP-Gripe,
para SRAG por covid-19 (CLASSI_FIN = 5), internados, semanas 1-47.

Uso: python src/calcular_dias_medios_sivep.py INFLUD25-....parquet INFLUD26-....parquet

Usa o leitor Parquet em Python puro (src/leitor_parquet) para não depender de pyarrow.
Se tiver pyarrow, pode trocar a função `ler` por pandas.read_parquet(arquivo, columns=COLS).

  dias totais  = DT_EVOLUCA - DT_INTERNA          (0 a 120 dias)
  dias de UTI  = DT_SAIDUTI - DT_ENTUTI, só para UTI = 1   (0 a 120 dias)
  dias de enfermaria = dias totais - dias de UTI (cada internado)
"""
import os, re, sys
import pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'leitor_parquet'))
from pq import load

COLS = {"SEM_NOT", "CLASSI_FIN", "HOSPITAL", "UTI", "DT_INTERNA", "DT_EVOLUCA", "DT_ENTUTI", "DT_SAIDUTI"}
for arq in sys.argv[1:]:
    ano = 2000 + int(re.search(r'INFLUD(\d{2})', arq.upper()).group(1))
    d = load(arq, COLS)
    for c in ["SEM_NOT", "CLASSI_FIN", "HOSPITAL", "UTI"]:
        d[c] = pd.to_numeric(d[c], errors='coerce')
    d = d[(d.CLASSI_FIN == 5) & (d.SEM_NOT <= 47) & (d.HOSPITAL == 1)]
    tot = (d.DT_EVOLUCA - d.DT_INTERNA).dt.days
    tot = tot.where((tot >= 0) & (tot <= 120))
    ut = (d.DT_SAIDUTI - d.DT_ENTUTI).dt.days
    ut = ut.where((ut >= 0) & (ut <= 120))
    isu = d.UTI == 1
    ut_dias = ut.where(isu)
    enf = (tot - ut_dias.fillna(0)).clip(lower=0)
    ok = tot.notna()
    print(ano, dict(internados=len(d), com_datas=int(ok.sum()),
                    dias_enfermaria_media=round(float(enf[ok].mean()), 1),
                    uti_pacientes=int(isu.sum()), uti_com_datas=int(ut_dias.notna().sum()),
                    dias_uti_media=round(float(ut_dias.mean()), 1)))
