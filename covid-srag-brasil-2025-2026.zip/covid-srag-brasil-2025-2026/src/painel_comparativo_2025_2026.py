"""
Comparativo COVID-19 (SRAG) 2025 x 2026 - SIVEP-Gripe.

  pip install streamlit pandas plotly pyarrow
  streamlit run painel_comparativo_2025_2026.py

Envie os arquivos de 2025 e 2026 (CSV ou Parquet) na barra lateral.
Cruzamentos: ano/semana epidemiológica, UF e município de residência,
classificação final, evolução, UTI, óbitos e faixa etária.
Custos NÃO existem na base: são estimativas com parâmetros seus.
"""
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="COVID-19 SRAG 2025 x 2026", layout="wide")
st.title("COVID-19 (SRAG): comparativo 2025 x 2026")

arqs = st.sidebar.file_uploader("Bases SIVEP-Gripe (2025 e 2026)",
                                type=["csv", "parquet"], accept_multiple_files=True)
st.sidebar.header("Custos estimados (R$)")
c_enf = st.sidebar.number_input("Diária enfermaria", 0, 20000, 600, 50)
c_uti = st.sidebar.number_input("Diária UTI", 0, 20000, 1600, 100)
d_enf = st.sidebar.number_input("Dias enfermaria (padrão)", 1, 60, 6)
d_uti = st.sidebar.number_input("Dias UTI (padrão)", 1, 60, 8)

COLS = ["DT_NOTIFIC", "SEM_NOT", "SG_UF", "CO_MUN_RES", "ID_MN_RESI", "CLASSI_FIN",
        "EVOLUCAO", "UTI", "HOSPITAL", "NU_IDADE_N", "TP_IDADE", "CS_SEXO"]


@st.cache_data(show_spinner="Lendo bases...")
def ler(nome, conteudo):
    import io, re
    b = io.BytesIO(conteudo)
    if nome.lower().endswith(".parquet"):
        import pyarrow.parquet as pq
        todas = pq.ParquetFile(b).schema_arrow.names
        sel = [c for c in todas if c.upper() in COLS]
        b.seek(0)
        df = pd.read_parquet(b, columns=sel)
    else:
        for enc in ("utf-8", "latin-1"):
            try:
                b.seek(0)
                df = pd.read_csv(b, sep=";", encoding=enc, low_memory=False,
                                 usecols=lambda c: c.upper() in COLS)
                break
            except UnicodeDecodeError:
                continue
    df.columns = [c.upper() for c in df.columns]
    # Datas: aceita ISO (AAAA-MM-DD) ou DD/MM/AAAA
    dt = df["DT_NOTIFIC"]
    if pd.api.types.is_datetime64_any_dtype(dt):
        df["DT_NOTIFIC"] = dt
    else:
        iso = dt.astype(str).str.match(r"^\d{4}-\d{2}-\d{2}").mean() > 0.5
        df["DT_NOTIFIC"] = pd.to_datetime(dt, errors="coerce") if iso else \
            pd.to_datetime(dt, dayfirst=True, errors="coerce")
    # Códigos podem vir como texto ("5") ou decimal (5.0)
    for c in ["SEM_NOT", "CLASSI_FIN", "EVOLUCAO", "UTI", "HOSPITAL",
              "NU_IDADE_N", "TP_IDADE"]:
        if c in df:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    # Ano = ano do arquivo (INFLUD25 -> 2025), senão ano da notificação
    m = re.search(r"INFLUD(\d{2})", nome.upper())
    df["ano"] = int("20" + m.group(1)) if m else df["DT_NOTIFIC"].dt.year
    return df


if not arqs:
    st.info("Envie os arquivos de 2025 e 2026 na barra lateral.")
    st.stop()

df = pd.concat([ler(a.name, a.getvalue()) for a in arqs], ignore_index=True)
df = df[df["ano"].isin([2025, 2026])]
df["SEM_NOT"] = pd.to_numeric(df["SEM_NOT"], errors="coerce")

# Apenas COVID-19 (CLASSI_FIN = 5)
if st.sidebar.checkbox("Somente COVID-19 (CLASSI_FIN = 5)", True):
    df = df[df["CLASSI_FIN"] == 5]

# Comparação justa: mesmas semanas epidemiológicas nos dois anos
if st.sidebar.checkbox("Limitar 2025 às semanas já disponíveis em 2026", True):
    smax = df.loc[df["ano"] == 2026, "SEM_NOT"].max()
    df = df[df["SEM_NOT"] <= smax]

ufs = sorted(df["SG_UF"].dropna().unique())
df = df[df["SG_UF"].isin(st.sidebar.multiselect("UF", ufs, default=ufs))]

df["obito"] = df["EVOLUCAO"].eq(2)
df["uti"] = df["UTI"].eq(1)
df["internado"] = df["HOSPITAL"].eq(1)
df["custo"] = df["internado"] * (
    df["uti"] * (d_uti * c_uti) + (~df["uti"]) * (d_enf * c_enf))
div = df["TP_IDADE"].map({1: 365, 2: 12, 3: 1})
df["faixa"] = pd.cut(df["NU_IDADE_N"] / div, [-1, 4, 11, 19, 39, 59, 79, 200],
                     labels=["0-4", "5-11", "12-19", "20-39", "40-59", "60-79", "80+"])

# ---- Resumo por ano ----
res = df.groupby("ano").agg(casos=("obito", "size"), internados=("internado", "sum"),
                            uti=("uti", "sum"), obitos=("obito", "sum"),
                            custo=("custo", "sum")).reset_index()
res["letalidade_%"] = (res["obitos"] / res["casos"] * 100).round(1)
st.subheader("Resumo")
st.dataframe(res, use_container_width=True, hide_index=True)

a, b = st.columns(2)
sem = df.groupby(["ano", "SEM_NOT"]).size().reset_index(name="casos")
a.plotly_chart(px.line(sem, x="SEM_NOT", y="casos", color="ano",
                       title="Casos por semana epidemiológica"), use_container_width=True)
f = df.groupby(["faixa", "ano"], observed=True).size().reset_index(name="casos")
b.plotly_chart(px.bar(f, x="faixa", y="casos", color="ano", barmode="group",
                      title="Casos por faixa etária"), use_container_width=True)

c, d = st.columns(2)
uf = df.groupby(["SG_UF", "ano"]).size().reset_index(name="casos")
c.plotly_chart(px.bar(uf, x="SG_UF", y="casos", color="ano", barmode="group",
                      title="Casos por UF de residência"), use_container_width=True)
ev = df.groupby(["ano", "EVOLUCAO"]).size().reset_index(name="n")
ev["evolucao"] = ev["EVOLUCAO"].map({1: "Cura", 2: "Óbito", 3: "Óbito outras causas",
                                     9: "Ignorado"})
d.plotly_chart(px.bar(ev, x="ano", y="n", color="evolucao", title="Evolução clínica"),
               use_container_width=True)

st.subheader("Top 15 municípios de residência")
mun = (df.groupby(["ano", "ID_MN_RESI"]).size().reset_index(name="casos")
         .sort_values("casos", ascending=False).groupby("ano").head(15))
st.plotly_chart(px.bar(mun, x="casos", y="ID_MN_RESI", color="ano", orientation="h",
                       barmode="group"), use_container_width=True)

st.subheader("Impacto financeiro estimado")
st.plotly_chart(px.bar(res, x="ano", y="custo", title="Custo estimado (R$)"),
                use_container_width=True)
st.caption("Custo = estimativa (internados x dias x diária). Não é valor oficial do SUS. "
           "Dados do SIVEP-Gripe são preliminares.")
