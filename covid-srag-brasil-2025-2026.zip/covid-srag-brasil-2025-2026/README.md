# COVID-19 (SRAG) no Brasil: 2025 × 2026 e simulador de impacto financeiro

Análise comparativa de SRAG por covid-19 hospitalizada (SIVEP-Gripe) em 2025 e 2026, com um simulador de impacto financeiro para celular.

**Resumo dos resultados** (base de 16/11/2026, semanas epidemiológicas 1 a 47):

| | 2025 | 2026 |
|---|---|---|
| Casos | 16.701 | 5.888 |
| Internados | 16.038 | 5.582 |
| Em UTI | 5.266 | 1.758 |
| Óbitos | 2.616 | 753 |
| Letalidade | 15,7% | 12,8% |

Os dados de 2026 são preliminares e a semana 47 está incompleta.

## Simulador de impacto financeiro
Custo estimado = internados × dias médios em enfermaria × diária de enfermaria + pacientes em UTI × dias médios em UTI × diária de UTI.

- **Diária de UTI: R$ 3.445**, custo real por paciente/dia (UTI covid, 2020, hospitais da FHEMIG). Média ponderada calculada a partir do artigo de Alemão et al. (2022).
- **Diária de enfermaria: R$ 89**, valor **pago pelo SUS** (SIH/SUS, Sudeste, 2025-2026), pois não há custo real público de enfermaria.
- **Dias médios:** 8,0 em enfermaria e 8,9 em UTI (SIVEP-Gripe).

> As duas diárias têm bases diferentes (custo × valor pago): o total subestima o custo real da enfermaria. Veja todas as limitações em [`docs/METODOLOGIA.md`](docs/METODOLOGIA.md).

## Estrutura

```
docs/
  FONTES.md            todas as fontes, links e o que foi usado de cada uma
  METODOLOGIA.md       definições, fórmulas, resultados e limitações
data/
  resumo.json                      agregados do SIVEP-Gripe usados pela página
  sih_resumo_diarias_sudeste.csv   diárias pagas pelo SUS por UF e ano
  sih_covid_amostra_sudeste.csv    1.654 AIH de covid (proxy B34.2) com descrição do procedimento
src/
  gerar_resumo.py                  Parquet/CSV do SIVEP-Gripe -> data/resumo.json
  calcular_dias_medios_sivep.py    médias de dias de enfermaria e UTI
  painel_comparativo_2025_2026.py  painel Streamlit (desktop)
  leitor_parquet/                  leitor Parquet em Python puro (sem pyarrow)
  sih/                             dbc2dbf.c, dbf.py, extrair_covid_sih.py, calcular_diarias.py
web/
  index.html                       página para celular com o simulador (arquivo único)
```

## Como reproduzir
Os dados brutos **não estão no repositório** (ver [`data/README.md`](data/README.md)).

```bash
pip install -r requirements.txt

# 1) Resumo do SIVEP-Gripe (gera resumo.json)
python src/gerar_resumo.py INFLUD25-16-11-2026.parquet INFLUD26-16-11-2026.parquet

# 2) Dias médios de internação
python src/calcular_dias_medios_sivep.py INFLUD25-16-11-2026.parquet INFLUD26-16-11-2026.parquet

# 3) Diárias pagas pelo SUS (arquivos RD do SIH em .zip)
gcc -O2 -o dbc2dbf src/sih/dbc2dbf.c
python src/sih/extrair_covid_sih.py pasta_com_zips saida_pkl
python src/sih/calcular_diarias.py saida_pkl

# 4) Painel desktop
streamlit run src/painel_comparativo_2025_2026.py
```

`web/index.html` é um arquivo único: abra no navegador ou publique no GitHub Pages. Para atualizar os números, gere um novo `resumo.json` e carregue-o na própria página.

## Fonte do custo de UTI
ALEMÃO, M. M. et al. *O custo do leito UTI do paciente COVID-19 em unidades hospitalares de Minas Gerais: referências para avaliação do modelo de financiamento durante a Pandemia.* Brazilian Journal of Health Review, v. 5, n. 2, p. 5661-5686, 2022. DOI: 10.34119/bjhrv5n2-145. https://ojs.brazilianjournals.com.br/ojs/index.php/BJHR/article/view/45925

## Licença
A definir pelo autor. Os dados de origem (SIVEP-Gripe, SIH/SUS) são públicos e anonimizados; consulte os termos de uso nos portais indicados em [`docs/FONTES.md`](docs/FONTES.md).
